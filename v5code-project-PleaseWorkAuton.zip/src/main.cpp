/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\brenn                                            */
/*    Created:      Mon Feb 01 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftBackMotor        motor         1               
// LeftFrontMotor       motor         19              
// RightBackMotor       motor         18              
// RightFrontMotor      motor         20              
// LeftIntake           motor         14              
// RightIntake          motor         15              
// FrontTower           motor         16              
// BackTower            motor         17              
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
int x=1;

competition Competition;
motor_group Intake(LeftIntake, RightIntake);
motor_group Tower(BackTower, FrontTower);
motor_group LeftWheels(LeftFrontMotor, LeftBackMotor);
motor_group RightWheels(RightFrontMotor, RightBackMotor);

void turn(char direction) {
  LeftWheels.spinFor(x, degrees, false);
  RightWheels.spinFor(-x, degrees, false);
}

void auton(void){
  FrontTower.setVelocity(100, percent);
  BackTower.setVelocity(100, percent);
  RightFrontMotor.setVelocity(100, percent);
  LeftBackMotor.setVelocity(100, percent);
  RightBackMotor.setVelocity(100, percent);
  LeftFrontMotor.setVelocity(100, percent);
  FrontTower.spinFor(180, degrees, false);
  //wait (.2, sec);
  //Intake.spinFor(360, degrees, false);
  //wait(.2, sec);
  //x=360;
  //turn('f');
  //wait(.2, sec);
}

void usercontrol(void) {
  while (1) {
  RightIntake.setVelocity(100, percent);
  LeftIntake.setVelocity(100, percent);
  FrontTower.setVelocity(100, percent);
  BackTower.setVelocity(100, percent);

  int leftdrive = Controller1.Axis3.position(percent);
  int rightdrive = Controller1.Axis2.position(percent);
  int side = -Controller1.Axis4.position(percent);
    RightFrontMotor.spin(forward, rightdrive, percent);
    LeftBackMotor.spin(forward, leftdrive, percent);
    RightBackMotor.spin(forward, rightdrive, percent);
    LeftFrontMotor.spin(forward, leftdrive, percent);
  if (side>80) {
    RightFrontMotor.spin(forward, side, percent);
    RightBackMotor.spin(forward, -side, percent);
    LeftFrontMotor.spin(forward, -side, percent);
    LeftBackMotor.spin(forward, side, percent);
  }
  if (Controller1.ButtonR2.pressing()){
    RightIntake.spin(directionType::fwd,100,velocityUnits::pct);
    LeftIntake.spin(directionType::fwd,100,velocityUnits::pct);
    }
    else if (Controller1.ButtonR1.pressing()){
    LeftIntake.spin(directionType::rev,100,velocityUnits::pct);
    RightIntake.spin(directionType::rev,100,velocityUnits::pct);
    }
    else{
    LeftIntake.stop();
    RightIntake.stop();
    };
  if (Controller1.ButtonL2.pressing()){
    FrontTower.spin(directionType::fwd,100,velocityUnits::pct);
    BackTower.spin(directionType::fwd,100,velocityUnits::pct);
    }
    else if (Controller1.ButtonUp.pressing()){
    FrontTower.spin(directionType::rev,100,velocityUnits::pct);
    BackTower.spin(directionType::rev,100,velocityUnits::pct);
    }
    else if (Controller1.ButtonL1.pressing()){
    BackTower.spin(directionType::rev,100,velocityUnits::pct);
    FrontTower.spin(directionType::fwd,100,velocityUnits::pct);
    }
    else{
    Tower.stop();
    }
    if (Controller1.ButtonX.pressing()) {
    RightFrontMotor.setVelocity(80, percent);
    LeftBackMotor.setVelocity(80, percent);
    RightBackMotor.setVelocity(80, percent);
    LeftFrontMotor.setVelocity(80, percent);
    }
    wait(20, msec);
  } 
}

int main() {
  Competition.autonomous(auton);
  Competition.drivercontrol(usercontrol);
}